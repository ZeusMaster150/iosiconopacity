#import <Preferences/PSListController.h>

@interface IOPRootListController : PSListController
@end
