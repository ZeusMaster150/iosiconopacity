#import <UIKit/UIKit.h>

// Домен настроек: файл /var/mobile/Library/Preferences/com.example.iconopacity.plist
static NSString *const kDomain = @"com.example.iconopacity";
static NSString *const kReloadNotification = @"com.example.iconopacity/ReloadPrefs";

static BOOL gEnabled = YES;
static CGFloat gAlpha = 0.8;
static NSHashTable *gViews; // слабые ссылки на иконки, чтобы менять их сразу

@interface SBIconView : UIView
@end

// Достаём картинку иконки (без подписи) из SBIconView.
static UIView *IconImageViewFor(UIView *iconView) {
    @try {
        id v = [iconView valueForKey:@"iconImageView"];
        if ([v isKindOfClass:[UIView class]]) return v;
    } @catch (NSException *e) {
    }
    return nil;
}

static void ApplyToIconView(UIView *iconView) {
    UIView *img = IconImageViewFor(iconView);
    if (!img) return;
    CGFloat target = gEnabled ? gAlpha : 1.0;
    if (img.alpha != target) {
        img.alpha = target;
    }
}

static void LoadPrefs(void) {
    CFStringRef domain = (__bridge CFStringRef)kDomain;
    CFPreferencesAppSynchronize(domain);
    id enabled = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("enabled"), domain);
    id alpha = (__bridge_transfer id)CFPreferencesCopyAppValue(CFSTR("alpha"), domain);

    gEnabled = [enabled respondsToSelector:@selector(boolValue)] ? [enabled boolValue] : YES;

    CGFloat a = 0.8;
    if ([alpha respondsToSelector:@selector(doubleValue)]) {
        a = [alpha doubleValue];
    }
    if (a < 0.1) a = 0.1;
    if (a > 1.0) a = 1.0;
    gAlpha = a;
}

// Вызывается, когда в Настройках двигают ползунок
static void ReloadPrefs(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    LoadPrefs();
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *v in gViews.allObjects) {
            ApplyToIconView(v);
        }
    });
}

%hook SBIconView
- (void)layoutSubviews {
    %orig;
    if (!gViews) {
        gViews = [NSHashTable weakObjectsHashTable];
    }
    [gViews addObject:self];
    ApplyToIconView(self);
}
%end

%ctor {
    LoadPrefs();
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    (CFNotificationCallback)ReloadPrefs,
                                    (__bridge CFStringRef)kReloadNotification,
                                    NULL,
                                    CFNotificationSuspensionBehaviorCoalesce);
}
